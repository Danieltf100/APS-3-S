
public class ExceptionCadastro extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ExceptionCadastro(String message){
		super(message);
	}
	
}
