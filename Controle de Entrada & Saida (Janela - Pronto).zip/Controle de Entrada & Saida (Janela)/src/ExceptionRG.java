
public class ExceptionRG extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ExceptionRG(String message){
		super(message);
	}
	
}
