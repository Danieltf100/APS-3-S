
public class ExceptionCatraca extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ExceptionCatraca(String message){
		super(message);
	}
	
}
